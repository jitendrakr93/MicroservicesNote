package in.nareshit.raghu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.StockQuote;
import in.nareshit.raghu.repo.StockQuoteRepository;

@Service
public class MessageStoreService {

	@Autowired
	private StockQuoteRepository repository;
	
	public void addStockData(StockQuote sq) {
		repository.save(sq);
	}
	
	public List<StockQuote> getAllStockQuotes() {
		return repository.findAll();
	}
}
