package in.nareshit.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudAppThreeTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudAppThreeTestApplication.class, args);
	}

}
