package in.nareshit.raghu.service;

import in.nareshit.raghu.model.User;

public interface IUserService {

	Integer saveUser(User user);
}
