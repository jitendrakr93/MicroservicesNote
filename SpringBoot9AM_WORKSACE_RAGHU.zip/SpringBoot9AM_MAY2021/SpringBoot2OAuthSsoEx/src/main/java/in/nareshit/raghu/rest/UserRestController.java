package in.nareshit.raghu.rest;

import java.security.Principal;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserRestController {

	@GetMapping("/home")
	public String showHome() {
		return "WELCOME TO ALL!!";
	}
	
	@GetMapping("/data")
	public String showSecure() {
		return "WELCOME SECURED PAGE";
	}
	
	@GetMapping("/user")
	public Authentication showUser(Principal p) {
		System.out.println(p.getClass().getName());
		System.out.println("Current user => " + p.getName());
		return SecurityContextHolder.getContext().getAuthentication();
		//return p;
	}
}
