package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.CircInfo;
import in.nareshit.raghu.service.MessageConverter;
import in.nareshit.raghu.service.ProducerSevice;

@Component
public class TestProducerRunner implements CommandLineRunner {

	@Autowired
	private ProducerSevice ps;

	public void run(String... args) throws Exception {
		ps.send("my-tpc1", MessageConverter.convertCircInfo(
				new CircInfo("NEW TEST ONE", "ABC", "IND", 251, 252, "IND-WINNER"))
				);
		System.out.println("SENT...");
	}

}
