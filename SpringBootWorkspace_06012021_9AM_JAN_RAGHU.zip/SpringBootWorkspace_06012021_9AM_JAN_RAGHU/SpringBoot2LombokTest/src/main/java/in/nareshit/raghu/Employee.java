package in.nareshit.raghu;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor //def
@RequiredArgsConstructor //1 param
@AllArgsConstructor //3 param
public class Employee {
	@NonNull
	private Integer eid; 
	private String ename;
	private Double esal; 
  
	// i want add one more const?? -- add manually
	public Employee(String ename) {
		this.ename=ename;
	}
}
