package in.nareshit.raghu;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MessageService {

	
	@Scheduled(cron = "* 50 * * * *")
	public void showMsg() {
		System.out.println("FROM MESSAGE " + new Date());
	}
	
}
