package in.nareshit.raghu.order.custom;

public interface CustomOrder {

	 int FIRST = -9999;
	
	 int NEXT = -1111;
	
	 int MID = 5555;
	
	 int LAST = 9999;
	
}
