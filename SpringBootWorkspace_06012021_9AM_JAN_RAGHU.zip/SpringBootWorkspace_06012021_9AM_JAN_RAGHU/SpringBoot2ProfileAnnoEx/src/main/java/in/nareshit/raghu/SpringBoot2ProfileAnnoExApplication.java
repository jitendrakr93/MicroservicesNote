package in.nareshit.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2ProfileAnnoExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2ProfileAnnoExApplication.class, args);
	}

}
