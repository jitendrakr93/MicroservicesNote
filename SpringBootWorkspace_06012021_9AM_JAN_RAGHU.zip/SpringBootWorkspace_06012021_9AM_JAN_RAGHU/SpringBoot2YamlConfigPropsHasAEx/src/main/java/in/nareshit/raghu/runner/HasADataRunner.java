package in.nareshit.raghu.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Student;
//ctrl+shift+O

@Component
@ConfigurationProperties(prefix = "my.app")
public class HasADataRunner implements CommandLineRunner {

	private Student sob;//HAS-A
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println(sob);
	}

	public Student getSob() {
		return sob;
	}

	public void setSob(Student sob) {
		this.sob = sob;
	}

	
}
