package in.nareshit.raghu.service;

public interface AlertService {

	public void showAlertMsg();
}
