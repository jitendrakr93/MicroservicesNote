package in.nareshit.raghu.runner;

import java.util.concurrent.TimeUnit;

import org.springframework.boot.CommandLineRunner;

//@Component
public class TimeFactorRunner implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		//3 days-> hours
		System.out.println(TimeUnit.DAYS.toHours(3));
		//3 days-> mins
		System.out.println(TimeUnit.DAYS.toMinutes(3));
		
		//1 sec-> nano sec
		System.out.println(TimeUnit.SECONDS.toNanos(1));
		//10 min-> mill sec
		System.out.println(TimeUnit.MINUTES.toMillis(10));
	}
}
