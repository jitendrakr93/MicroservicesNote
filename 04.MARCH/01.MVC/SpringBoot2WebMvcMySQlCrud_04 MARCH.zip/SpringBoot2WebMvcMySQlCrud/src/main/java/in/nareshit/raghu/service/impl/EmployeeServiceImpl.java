package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.repo.EmployeeRepository;
import in.nareshit.raghu.service.IEmployeeService;

@Service // = @Component + Logics/cal + TxManagement
public class EmployeeServiceImpl
implements IEmployeeService
{

	@Autowired
	private EmployeeRepository repo; //HAS-A

	public Integer saveEmployee(Employee e) {
		//JDK 10# Local Variable Type Inference
		//the best datatype is selected at compile time
		//---calculations--
		var sal = e.getEmpSal();
		var hra = sal * 12/100;
		var ta = sal * 3/100;

		//set data to model cls obj
		e.setEmpHra(hra);
		e.setEmpTa(ta);

		//save data in db
		//this method again returns same object
		// with PK updated value
		e = repo.save(e);

		//PK
		Integer empId = e.getEmpId();

		return empId;
	}

	public List<Employee> getAllEmployees() {
		List<Employee> list = repo.findAll();
		return list;
	}

	public void deleteEmployee(Integer id) {
		repo.deleteById(id);
	}

	public Optional<Employee> getOneEmployee(Integer id) {
		return repo.findById(id);
	}

	public void updateEmployee(Employee e) {
		
		if(repo.existsById(e.getEmpId())) {
			var sal = e.getEmpSal();
			var hra = sal * 12/100;
			var ta = sal * 3/100;

			e.setEmpHra(hra);
			e.setEmpTa(ta);
			
			repo.save(e);
		}
	}

}
