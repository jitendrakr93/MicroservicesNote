package in.nareshit.raghu.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.service.IEmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private IEmployeeService service;//HAS-A

	//1. To Display Register Page
	@GetMapping("/register")
	public String showRegPage() {
		return "EmployeeRegister";
	}

	/**
	 * 2. On Click submit button read form data
	 *    using @ModelAttribute.
	 *    Call service method for saveEmp
	 *    Read PK(ID) Integer and create String msg
	 *    send Message Back to UI using Model.
	 *    Provide Path /save with POST Type.
	 */
	@PostMapping("/save")
	public String saveEmp(
			@ModelAttribute Employee employee,
			Model model
			) 
	{
		Integer id = service.saveEmployee(employee);
		String msg = "Employee '"+id+"' saved";
		model.addAttribute("message", msg);

		return "EmployeeRegister";
	}

	/**
	 * 3. On Enter URL /all + GET Type,
	 *    fetch data from service as List<T>
	 *    Use Model memory to send data to UI.
	 *    Display at EmployeeData Page 
	 */
	@GetMapping("/all")
	public String showAllEmps(Model model) {
		getUiEmployeeTableData(model);
		return "EmployeeData";
	}
	
	private void getUiEmployeeTableData(Model model) {
		List<Employee> list = service.getAllEmployees();
		model.addAttribute("list", list);
	}

	/***
	 * 4. Read Id using Request Param
	 * 	  call service for delete operation
	 * 	  redirect back to all page(no message)
	 * 
	 */
	@GetMapping("/delete")
	public String deleteEmp(
			@RequestParam("id") Integer empId,
			Model model
			) 
	{
		service.deleteEmployee(empId);

		//fetch latest data after delete
		getUiEmployeeTableData(model);

		model.addAttribute("msg", "Employee '"+empId+"' Deleted");
		return "EmployeeData";
		//return "redirect:all";
	}

	/***
	 * 5. Show Data in Edit Page
	 *    Read ReqParam 'id', 
	 *    call service -> Get optional object.
	 *    If data present-> Goto edit page
	 *    else come back to data page.
	 */
	@GetMapping("/edit")
	public String showEdit(
			@RequestParam("id")Integer id,
			Model model
			) 
	{
		String page = null;
		Optional<Employee> opt = service.getOneEmployee(id);

		if(opt.isPresent()) {
			Employee emp = opt.get();
			model.addAttribute("employee", emp);
			page = "EmployeeEdit";
		} else {
			page = "redirect:all";
		}

		return page;
	}

	/***
	 * 6. On click FORM Update, Read ModelAttribute
	 *    Perform updateMethod call.
	 *    Send Redirect/ Fetch Latest Data goto DataPage
	 */
	@PostMapping("/update")
	public String updateEmployee(
			@ModelAttribute Employee employee,
			Model model
			) 
	{
		service.updateEmployee(employee);


		//fetch latest data after delete
		getUiEmployeeTableData(model);
		
		//create message and display at UI
		model.addAttribute("msg", "Employee '"+employee.getEmpId()+"' Updated!!");
		return "EmployeeData";
		//return "redirect:all";
	}

}
